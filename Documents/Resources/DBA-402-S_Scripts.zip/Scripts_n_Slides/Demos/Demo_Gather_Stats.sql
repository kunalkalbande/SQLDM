USE Northwind
GO

TRUNCATE TABLE [dbo].[waitstats]
TRUNCATE TABLE [dbo].[filestats]



exec dbo.gather_waitstats_2005
exec dbo.gather_filestats_2005

GO
--WAITFOR DELAY '00:30:00'
WAITFOR DELAY '00:05:00'

exec dbo.gather_waitstats_2005
exec dbo.gather_filestats_2005
GO
/*
exec dbo.report_waitstats_2005

exec dbo.report_filestats_2005
*/