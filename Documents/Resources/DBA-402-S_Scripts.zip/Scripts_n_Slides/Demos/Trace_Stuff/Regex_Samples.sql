

select dbo.SQL_Signature('select * from orders where orderid = 10255 AND MyDate = ''2006-01-01''',1000)

select dbo.fn_SQLSigCLR('select * from orders where orderid = 10255 AND MyDate = ''2006-01-01''')

SELECT dbo.fn_RegexReplace('select * from orders where orderid = 10255 AND MyDate = ''2006-01-01''',
   N'([\s,(=<>!](?![^\]]+[\]]))(?:(?:(?:(?#    expression coming
     )(?:([N])?('')(?:[^'']|'''')*(''))(?#      character
     )|(?:0x[\da-fA-F]*)(?#                     binary
     )|(?:[-+]?(?:(?:[\d]*\.[\d]*|[\d]+)(?#     precise number
     )(?:[eE]?[\d]*)))(?#                       imprecise number
     )|(?:[~]?[-+]?(?:[\d]+))(?#                integer
     ))(?:[\s]?[\+\-\*\/\%\&\|\^][\s]?)?)+(?#   operators
     ))', N'$1$2$3#$4')


--  Parse a file the CLR way
select dbo.fn_SQLSigCLR([TextData])
  FROM ::fn_trace_gettable('C:\Presentations\PASS2007\PPM\Demos\Trace_Stuff\Sample_1_Trace.trc', default)

--  Parse a file the TSQL way
select dbo.SQL_Signature([TextData],1000)
  FROM ::fn_trace_gettable('C:\Presentations\PASS2007\PPM\Demos\Trace_Stuff\Sample_1_Trace.trc', default)


SELECT dbo.fn_RegexReplace([TextData],
   N'([\s,(=<>!](?![^\]]+[\]]))(?:(?:(?:(?#    expression coming
     )(?:([N])?('')(?:[^'']|'''')*(''))(?#      character
     )|(?:0x[\da-fA-F]*)(?#                     binary
     )|(?:[-+]?(?:(?:[\d]*\.[\d]*|[\d]+)(?#     precise number
     )(?:[eE]?[\d]*)))(?#                       imprecise number
     )|(?:[~]?[-+]?(?:[\d]+))(?#                integer
     ))(?:[\s]?[\+\-\*\/\%\&\|\^][\s]?)?)+(?#   operators
     ))', N'$1$2$3#$4')
  FROM ::fn_trace_gettable('C:\Presentations\PASS2007\PPM\Demos\Trace_Stuff\Sample_1_Trace.trc', default)



SELECT dbo.fn_SQLSigCLR([TextData]) AS [QueryClass], COUNT(*) AS [Totals]
    FROM ::fn_trace_gettable('C:\Presentations\PASS2007\PPM\Demos\Trace_Stuff\Sample_4_Trace.trc', default)
GROUP BY dbo.fn_SQLSigCLR([TextData])


SELECT  dbo.fn_RegexReplace([TextData],
   N'([\s,(=<>!](?![^\]]+[\]]))(?:(?:(?:(?#    expression coming
     )(?:([N])?('')(?:[^'']|'''')*(''))(?#      character
     )|(?:0x[\da-fA-F]*)(?#                     binary
     )|(?:[-+]?(?:(?:[\d]*\.[\d]*|[\d]+)(?#     precise number
     )(?:[eE]?[\d]*)))(?#                       imprecise number
     )|(?:[~]?[-+]?(?:[\d]+))(?#                integer
     ))(?:[\s]?[\+\-\*\/\%\&\|\^][\s]?)?)+(?#   operators
     ))', N'$1$2$3#$4'), COUNT(*) AS [Totals]
  FROM ::fn_trace_gettable('C:\Presentations\PASS2007\PPM\Demos\Trace_Stuff\Sample_1_Trace.trc', default)
GROUP BY dbo.fn_RegexReplace([TextData],
   N'([\s,(=<>!](?![^\]]+[\]]))(?:(?:(?:(?#    expression coming
     )(?:([N])?('')(?:[^'']|'''')*(''))(?#      character
     )|(?:0x[\da-fA-F]*)(?#                     binary
     )|(?:[-+]?(?:(?:[\d]*\.[\d]*|[\d]+)(?#     precise number
     )(?:[eE]?[\d]*)))(?#                       imprecise number
     )|(?:[~]?[-+]?(?:[\d]+))(?#                integer
     ))(?:[\s]?[\+\-\*\/\%\&\|\^][\s]?)?)+(?#   operators
     ))', N'$1$2$3#$4')
