CREATE FUNCTION SQL_Signature 
	(@p1 ntext, @ParseLength int = 4000)
RETURNS nvarchar(4000)

--
-- This function is provided "AS IS" with no warranties, and confers no rights. 
-- Use of included script samples are subject to the terms specified at http://www.microsoft.com/info/cpyright.htm
-- 
-- Strips query strings in sysprocesses
AS
BEGIN 
	DECLARE @pos as INT
	DECLARE @mode as CHAR(10)
	DECLARE @maxlength as INT
	DECLARE @p2 as NCHAR(4000)
	DECLARE @currchar as CHAR(1), @nextchar as CHAR(1)
	DECLARE @p2len as INT

	SET @maxlength = len(rtrim(substring(@p1,1,4000)));
	SET @maxlength = case when @maxlength > @parselength 
			then @parselength else @maxlength end
	SET @pos = 1;
	SET @p2 = '';
	SET @p2len = 0;
	SET @currchar = ''
	set @nextchar = ''
	SET @mode = 'command';

	WHILE (@pos <= @maxlength) BEGIN
		SET @currchar = substring(@p1,@pos,1)
		SET @nextchar = substring(@p1,@pos+1,1)
		IF @mode = 'command' BEGIN
			SET @p2 = left(@p2,@p2len) + @currchar
			SET @p2len = @p2len + 1 
			IF @currchar in (',','(',' ','=','<','>','!') and
			   @nextchar between '0' and '9' BEGIN
				set @mode = 'number'
				SET @p2 = left(@p2,@p2len) + '#'
				SET @p2len = @p2len + 1
				END 
			IF @currchar = '''' BEGIN
				set @mode = 'literal'
				SET @p2 = left(@p2,@p2len) + '#'''
				SET @p2len = @p2len + 2 
				END
			END
		ELSE IF @mode = 'number' and @nextchar in (',',')',' ','=','<','>','!')
			SET @mode= 'command'
		ELSE IF @mode = 'literal' and @currchar = ''''
			SET @mode= 'command'

		SET @pos = @pos + 1
	END
	RETURN @p2 

END
GO
