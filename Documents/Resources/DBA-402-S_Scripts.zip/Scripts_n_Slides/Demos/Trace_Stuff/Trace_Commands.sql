
--  List the current traces
SELECT * FROM :: fn_trace_getinfo(default) 


/*

--  Stop the trace
EXEC sp_trace_setstatus 2,0

--  Close and Remove the trace
EXEC sp_trace_setstatus 2,2


select * from sys.traces

select a.[EventID], b.[name], a.[ColumnID], c.[name]
from fn_trace_geteventinfo( 1 ) AS a INNER JOIN sys.trace_events as b
ON a.EventID = b.Trace_Event_ID
INNER JOIN sys.trace_columns as c
ON a.ColumnID = c.Trace_Column_ID
ORDER BY a.[EventID], a.[ColumnID]

select * from fn_trace_getfilterinfo(1)

select a.[ColumnID], c.[name], c.*
from fn_trace_getfilterinfo( 1 ) AS a INNER JOIN sys.trace_columns as c
ON a.ColumnID = c.Trace_Column_ID
ORDER BY a.[ColumnID]


SELECT  [EventClass], [TextData], [Duration], [Reads], [Writes], [CPU], [DatabaseID], [StartTime], [NTUserName], 
    [ClientProcessID], [ApplicationName], [LoginName], [SPID],  [Severity], [ServerName]
INTO [dbo].[TraceTable]
    FROM ::fn_trace_gettable('Path\FileName.trc', default)

*/
