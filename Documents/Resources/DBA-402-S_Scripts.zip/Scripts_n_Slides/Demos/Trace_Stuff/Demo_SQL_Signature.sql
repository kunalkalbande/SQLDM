

SELECT  TOP 1000 [EventClass], [TextData], [Duration], [Reads], [Writes], [CPU], [DatabaseID], [StartTime], [NTUserName], 
    [ClientProcessID], [ApplicationName], [LoginName], [SPID],  [Severity], [ServerName]
    FROM ::fn_trace_gettable('C:\Presentations\PASS2007\Finals\PPM\Demos\Trace_Stuff\Sample_1_Trace.trc', default)



SELECT TOP 1000 dbo.SQL_Signature([TextData],4000) AS [TextData]
    FROM ::fn_trace_gettable('C:\Presentations\PASS2007\Finals\PPM\Demos\Trace_Stuff\Sample_1_Trace.trc', default)



SELECT a.[TextData], COUNT(*) AS [Totals], SUM([Duration]) AS [Total Duration], MAX([CPU]) AS [Max CPU]
FROM (SELECT TOP 1000 dbo.SQL_Signature([TextData],4000) AS [TextData], [Duration], [CPU]
    FROM ::fn_trace_gettable('C:\Presentations\PASS2007\Finals\PPM\Demos\Trace_Stuff\Sample_1_Trace.trc', default)) AS a
WHERE [TextData] <> ''
GROUP BY a.[TextData]
