USE [Presents]
GO

SELECT b.[name], a.*
FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
    AND b.[name] LIKE '%Customers%'
    AND a.[object_id] > 1000;


DELETE FROM [dbo].[customers] WHERE [CustomerID] = 'PMDB_1'
DELETE FROM [dbo].[customers] WHERE [CustomerID] = 'PMDB_2'
DELETE FROM [dbo].[customers] WHERE [CustomerID] = 'PMDB_3'

INSERT INTO [Presents].[dbo].[Customers]
    ([CustomerID],[CompanyName],[ContactName],[ContactTitle],[Address],[City],
    [Region],[PostalCode],[Country],[Phone],[Fax],[Cycle])
VALUES
   ('PMDB_1','Solid Quality Mentors','Andrew J. Kelly','MVP','Somewhere','Plaistow',
    'NA','03865','USA','1234567899','1234567899',1)


SELECT * FROM [dbo].[Customers] WHERE [CustomerID] = 'PMDB_1'

UPDATE [dbo].[Customers] SET [Region] = 'None' WHERE [CustomerID] = 'PMDB_1'

INSERT INTO [Presents].[dbo].[Customers]
    ([CustomerID],[CompanyName],[ContactName],[ContactTitle],[Address],[City],
    [Region],[PostalCode],[Country],[Phone],[Fax],[Cycle])
VALUES
   ('PMDB_2','Solid Quality Mentors','Andrew J. Kelly','MVP','Somewhere','Plaistow',
    'NA','03865','USA','1234567899','1234567899',1)

SELECT * FROM [dbo].[Customers] WHERE [CustomerID] = 'PMDB_2'


INSERT INTO [Presents].[dbo].[Customers]
    ([CustomerID],[CompanyName],[ContactName],[ContactTitle],[Address],[City],
    [Region],[PostalCode],[Country],[Phone],[Fax],[Cycle])
VALUES
   ('PMDB_3','Solid Quality Mentors','Andrew J. Kelly','MVP','Somewhere','Plaistow',
    'NA','03865','USA','1234567899','1234567899',1)


SELECT * FROM [dbo].[Customers] WHERE [CustomerID] = 'PMDB_3'


SELECT b.[name], a.*
FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
    AND b.[name] LIKE '%Customers%'
    AND a.[object_id] > 1000;


-- Rebuild the index
ALTER INDEX [IX_Customers_CustomerID] ON [dbo].[Customers] REBUILD

ALTER INDEX [IX_Customers_CompanyName] ON [dbo].[Customers] REBUILD

--  What happened to the stats?
SELECT b.[name], a.*
FROM sys.dm_db_index_operational_stats(NULL, NULL, NULL, NULL) AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
    AND b.[name] LIKE '%Customers%'
    AND a.[object_id] > 1000;

--  Look for blocking
SELECT * FROM [sys].[dm_db_index_operational_stats](NULL,NULL,NULL,NULL)
    WHERE [row_lock_wait_in_ms] > 0 OR [page_lock_wait_in_ms] > 0
        ORDER BY [row_lock_wait_in_ms] DESC
