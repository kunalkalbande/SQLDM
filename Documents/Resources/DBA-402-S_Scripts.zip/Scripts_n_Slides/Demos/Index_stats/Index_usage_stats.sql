

SELECT b.[name], a.*
FROM sys.dm_db_index_usage_stats AS a
    INNER JOIN sys.indexes AS b ON a.[object_id] = b.[object_id] AND 
    a.[index_id] = b.[index_id]
WHERE a.[database_id] = DB_ID()
 AND a.[object_id] > 1000;

SELECT * FROM Customers WHERE Companyname = 'Let''s Stop N Shop'

SELECT Companyname FROM Customers WHERE Companyname = 'Let''s Stop N Shop'

SELECT Companyname, ContactName FROM Customers WHERE Companyname = 'Let''s Stop N Shop'

SELECT Companyname, CustomerID FROM Customers WHERE Companyname = 'Let''s Stop N Shop'

SELECT * FROM Customers WHERE CustomerID = 'LETSS'

SELECT * FROM Customers 

sp_helpindex customers

