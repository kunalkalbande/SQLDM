SET NOCOUNT ON

DECLARE @WarningLevel INT 
SET @WarningLevel = 15  --  % of free disk space left before warning

DECLARE @hr int,  @fso int, @drive char(1), @odrive int, @TotalSize varchar(20)
DECLARE @MB bigint ; SET @MB = 1048576

CREATE TABLE #drives ([drive] char(1), [FreeSpace] int NULL,  [TotalSize] int NULL, [FreePercentage] INT NULL)
--  Get a list of drives available on the server
INSERT #drives([drive], [FreeSpace]) 
    EXEC master.dbo.xp_fixeddrives

--  Create the FSO 
EXEC @hr=sp_OACreate 'Scripting.FileSystemObject',@fso OUT
IF @hr <> 0 
    EXEC sp_OAGetErrorInfo @fso

--  For each drive get the space info
DECLARE curDrives CURSOR LOCAL FAST_FORWARD
FOR 
SELECT [drive] 
    FROM #drives
        ORDER BY [drive]

OPEN curDrives

FETCH NEXT FROM curDrives INTO @drive

WHILE @@FETCH_STATUS = 0
BEGIN

        EXEC @hr = sp_OAMethod @fso,'GetDrive', @odrive OUT, @drive
        IF @hr <> 0 
            EXEC sp_OAGetErrorInfo @fso
        
        EXEC @hr = sp_OAGetProperty @odrive,'TotalSize', @TotalSize OUT
        IF @hr <> 0 
            EXEC sp_OAGetErrorInfo @odrive
                        
        UPDATE #drives SET [TotalSize] = @TotalSize / @MB
            WHERE [drive] = @drive
        
        FETCH NEXT FROM curDrives INTO @drive

END

CLOSE curDrives
DEALLOCATE curDrives

EXEC @hr=sp_OADestroy @fso
IF @hr <> 0 
    EXEC sp_OAGetErrorInfo @fso

PRINT   '**** ' + CONVERT(VARCHAR(26),GETDATE(),109) + ' ****' + CHAR(13) + CHAR(10) + CHAR(13) + CHAR(10)

UPDATE #drives SET [FreePercentage] = CAST(([FreeSpace] / ([TotalSize] * 1.0)) * 100.0 as int)
SELECT [drive],
       [TotalSize] AS 'Total(MB)',
       [FreeSpace] AS 'Free(MB)',
       [FreePercentage] AS 'Free(%)'
FROM #drives
ORDER BY [drive]

IF EXISTS (SELECT * FROM #drives AS a WHERE a.[FreePercentage] < @WarningLevel)
BEGIN
    DECLARE @Msg VARCHAR(500)
    SET @Msg = 'Warning:  Low disk space on server: ' + CONVERT(NVARCHAR(128), SERVERPROPERTY('servername'))
    RAISERROR( @Msg,14,1)
END

DROP TABLE #drives




