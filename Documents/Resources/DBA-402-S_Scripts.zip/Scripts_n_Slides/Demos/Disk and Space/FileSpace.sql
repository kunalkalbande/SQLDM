SET NOCOUNT ON

DECLARE @FreeSpace INT, @DBName NVARCHAR(128), @Sql NVARCHAR(2000)

CREATE TABLE #FreeSpace ([DBName] NVARCHAR(128), [DBSize] DECIMAL(15,2), [FreeSpace] DECIMAL(15,2), [PercentFree] DECIMAL(5,1), [FreeTH] INT)

DECLARE curDBs CURSOR
READ_ONLY STATIC
FOR 
SELECT a.[name] AS [DBName]
    FROM [master].[sys].[databases] AS a 
WHERE UPPER(a.[name]) NOT IN ('MASTER','MODEL','MSDB','TEMPDB')
            AND DATABASEPROPERTYEX(a.[Name],'Status')='ONLINE'
    ORDER BY a.[name]

OPEN curDBs

FETCH NEXT FROM curDBs INTO @DBName

WHILE (@@fetch_status = 0)
BEGIN


    SET @Sql = 'USE ' + @DBName + 
        ' DECLARE @dbsize dec(15,0), @pagesperMB dec(15,0)
 
        SELECT @dbsize = SUM(CONVERT(DEC(15),size))
            FROM [dbo].[sysfiles]
                WHERE (status & 64 = 0)
        
        SET @pagesperMB = 1048576 / 8192

        INSERT INTO #FreeSpace ([DBName], [DBSize], [FreeSpace], [FreeTH])
            SELECT ''' + @DBName + ''',
        @dbsize / @pagesperMB ,
        (@dbsize - (SELECT SUM(CONVERT(DEC(15),[reserved])) 
                                                FROM [dbo].[sysindexes]
                                                    WHERE [indid] IN (0, 1, 255))) / @pagesperMB AS [Free Space] , ' + CAST(10 AS VARCHAR(4))


    EXEC(@Sql)

    FETCH NEXT FROM curDBs INTO @DBName
END

CLOSE curDBs
DEALLOCATE curDBs

UPDATE #FreeSpace SET [PercentFree] = CAST(([FreeSpace] / [DBSize]) * 100 AS DECIMAL(5,1))

--select * from #FreeSpace

SELECT CAST([DBName] AS VARCHAR(30)) AS [DB Name], 
    [DBSize] AS [DB Size MB], 
    [FreeSpace] AS [Free Space MB], [PercentFree] AS [% Free],
    [FreeTH] AS [TH %]
FROM #FreeSpace

DROP TABLE #FreeSpace




