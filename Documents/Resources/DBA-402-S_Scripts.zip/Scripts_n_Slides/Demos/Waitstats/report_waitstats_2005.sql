IF EXISTS (SELECT * FROM sys.objects WHERE [object_id] = OBJECT_ID(N'[dbo].[report_waitstats_2005]') and OBJECTPROPERTY([object_id], N'IsProcedure') = 1)
	DROP PROCEDURE [dbo].[report_waitstats_2005]
GO
CREATE PROCEDURE [dbo].[report_waitstats_2005] 
(@Last_Time DATETIME = NULL
,@UseOLEDB INT = 0) 
/*
 --  Date & time of the last sample to use
 --  0 = Dont include OLEDB waits, 1 = Include OLEDB waits
*/
AS

SET NOCOUNT ON

IF NOT EXISTS (SELECT * FROM sysobjects WHERE [id] = OBJECT_ID ( N'[dbo].[waitstats]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
BEGIN
		RAISERROR('Error [dbo].[waitstats] table does not exist', 16, 1) WITH NOWAIT
		RETURN
END

DECLARE @Total_Wait numeric(20,1), @Total_SignalWait numeric(20,1), @Total_ResourceWait numeric(20,1)
	,@EndTime datetime,@BeginTime datetime, @Total_Requests Bigint

DECLARE @Waits TABLE ([wait_type] nvarchar(60) not null, 
    [waiting_tasks_count] bigint not null,
    [wait_time_ms] bigint not null,
    [max_wait_time_ms] bigint not null,
    [signal_wait_time_ms] bigint not null,
    [capture_time] datetime not null)

--  If no time was specified then use the latest sample
IF @Last_Time IS NULL
    SET @Last_Time = (SELECT MAX([capture_time]) FROM [dbo].[waitstats])
ELSE
BEGIN
    --  If the time was not specified exactly find the closest one
    IF NOT EXISTS(SELECT * FROM [dbo].[waitstats] WHERE [capture_time] = @Last_Time)
    BEGIN
        DECLARE @LT DATETIME
        SET @LT = @Last_Time

        SET @Last_Time = (SELECT MAX([capture_time]) FROM [dbo].[waitstats] WHERE [capture_time] <= @LT)
        IF @Last_Time IS NULL
            SET @Last_Time = (SELECT MIN([capture_time]) FROM [dbo].[waitstats] WHERE [capture_time] >= @LT)
    END
END
SET @EndTime = @Last_Time

--  Get the relevant waits
INSERT INTO @Waits ([wait_type], [waiting_tasks_count], [wait_time_ms], [max_wait_time_ms], [signal_wait_time_ms], [capture_time])
    SELECT [wait_type], [waiting_tasks_count], [wait_time_ms], [max_wait_time_ms], [signal_wait_time_ms], [capture_time]
        FROM [dbo].[waitstats] WHERE [capture_time] = @Last_Time 

IF @@ROWCOUNT = 0
BEGIN
    RAISERROR('Error, there are no waits for the specified DateTime', 16, 1) WITH NOWAIT
    RETURN
END
    
SET @BeginTime = (SELECT MIN([capture_time]) 
                    FROM [dbo].[waitstats])

--  Delete some of the misc types of waits and OLEDB if called for
IF @UseOLEDB = 0
    DELETE FROM @Waits 
        WHERE [wait_type] IN ('CLR_SEMAPHORE','LAZYWRITER_SLEEP','RESOURCE_QUEUE','SLEEP_TASK','SLEEP_SYSTEMTASK','SQLTRACE_BUFFER_FLUSH','WAITFOR', 'OLEDB')
ELSE
    DELETE FROM @Waits 
        WHERE [wait_type] IN ('CLR_SEMAPHORE','LAZYWRITER_SLEEP','RESOURCE_QUEUE','SLEEP_TASK','SLEEP_SYSTEMTASK','SQLTRACE_BUFFER_FLUSH','WAITFOR')

SELECT @Total_Wait = SUM([wait_time_ms]) + 1, @Total_SignalWait = SUM([signal_wait_time_ms]) + 1 
    FROM @Waits 

SET @Total_ResourceWait = (1 + @Total_Wait) - @Total_SignalWait

-- Get total Requests
SET @Total_Requests = (SELECT SUM([waiting_tasks_count]) FROM @Waits)


INSERT INTO @Waits ([wait_type], [waiting_tasks_count], [wait_time_ms], [max_wait_time_ms], [signal_wait_time_ms], [capture_time])
    SELECT '***Total***',@Total_Requests,@Total_Wait,0,@Total_SignalWait,@Last_Time 

SELECT @BeginTime AS [Start Time], @EndTime AS [End Time]
    ,CONVERT(varchar(50),@EndTime-@BeginTime,14) AS [Duration (hh:mm:ss:ms)]

select [wait_type] AS [Wait Type]
    ,[waiting_tasks_count] AS [Requests]
	,[wait_time_ms] AS [Total Wait Time (ms)]
    ,[max_wait_time_ms] AS [Max Wait Time (ms)]
	,CAST(100 * [wait_time_ms] / @Total_Wait as numeric(20,1)) AS [% Waits]
	,[wait_time_ms] - [signal_wait_time_ms] AS [Resource Waits (ms)]
	,CAST(100 * ([wait_time_ms] - [signal_wait_time_ms]) / @Total_ResourceWait as numeric(20,1)) AS [% Res Waits]
	,[signal_wait_time_ms] AS [Signal Waits (ms)]
	,CAST(100*[signal_wait_time_ms] / @Total_SignalWait as numeric(20,1)) AS [% Signal Waits]
FROM @Waits 
    ORDER BY [Total Wait Time (ms)] DESC, [Wait Type]




