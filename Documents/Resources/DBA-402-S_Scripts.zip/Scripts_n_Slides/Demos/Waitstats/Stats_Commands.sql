/*
exec dbo.gather_waitstats_2005
exec dbo.gather_filestats_2005
*/


exec dbo.report_waitstats_2005

--exec dbo.report_filestats_2005
