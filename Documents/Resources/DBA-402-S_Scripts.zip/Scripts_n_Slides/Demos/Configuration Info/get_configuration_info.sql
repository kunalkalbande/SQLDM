SELECT * FROM sys.configurations
ORDER BY name ; 
