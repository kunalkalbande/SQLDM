--SELECT * FROM sys.dm_os_memory_objects 


-- ***  Change to TEXT Results before running.  Save results to text file   ***

SELECT (SUM([pages_allocated_count] * [page_size_in_bytes]) / 1024) AS 'KBytes Used', [type] 
    FROM sys.dm_os_memory_objects
        GROUP BY [type] 
            ORDER BY 1 DESC;



DBCC MEMORYSTATUS


SELECT (SUM([pages_allocated_count] * [page_size_in_bytes]) / 1024) AS 'KBytes Used', [type] 
    FROM sys.dm_os_memory_objects
        GROUP BY [type] 
            ORDER BY 1 DESC;


SELECT (SUM(([single_pages_kb] + [multi_pages_kb]) * [page_size_bytes]) / 1024) AS 'KBytes Used', [type] 
FROM sys.dm_os_memory_clerks 
WHERE [type] LIKE 'MEMORYCLERK_%'
GROUP BY [type]
ORDER BY 1 DESC
