USE Trace_Junk


SELECT * FROM CounterData
SELECT * FROM CounterDetails
SELECT * FROM DisplayToID


