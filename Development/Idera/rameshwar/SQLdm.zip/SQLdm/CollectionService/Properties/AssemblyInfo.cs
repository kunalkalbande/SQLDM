﻿using System.Reflection;
using System.Management.Instrumentation;

[assembly: AssemblyTitle("IDERA SQLdm Collection Service")]
[assembly: AssemblyDescription("")]

[assembly: Instrumented("Root/Idera/SQLdm/CollectionService")]