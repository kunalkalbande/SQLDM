﻿--------------------------------------------------------------------------------
--  Batch: Activity Profiler Stop Trace 2005
--  Tables: none
--  XSP:  none
--	Variables: [0] - Restart variable name
--------------------------------------------------------------------------------\
--Disabled for Azure