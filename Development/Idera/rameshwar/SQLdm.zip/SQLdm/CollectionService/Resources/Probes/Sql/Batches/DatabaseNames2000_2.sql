﻿--------------------------------------------------------------
-- SQLDM 11 - Recommended changes for Azure SQL Database v12
--------------------------------------------------------------

SELECT name 'DatabaseName', dbid 'ID'
FROM sysdatabases