-- SQLdm 6.1SP2  Hashvalue: RwpfxjnfaoCc9fxsSIkFY1wp57Q= 
set nocount on


declare 
	@servername varchar(255), 
	@sysperfinfoname varchar(255),
	@slashpos int

select @servername = cast(serverproperty('servername') as nvarchar(255))

select @servername = upper(@servername) 

select @slashpos = charindex('\', @servername)  

if @slashpos <> 0 
	begin 
		select @sysperfinfoname = 'MSSQL$' + substring(@servername, @slashpos + 1, 30) 
	end  
else 
	begin 
		select @sysperfinfoname = 'SQLSERVER'
	end  


-- BMT - Had to modify this batch so that the results are returned in a consistent order regardless of the 
--   collation of the mater database of a server.
select lower('Cache Pages'), cntr_value
from master..sysperfinfo
where counter_name = 'Procedure cache pages'
union
select lower('Committed Pages'), cntr_value
from master..sysperfinfo
where counter_name = 'Database pages' and lower(object_name) = lower(@sysperfinfoname + ':Buffer Manager')
union
select lower('Connection Memory (KB)'), cntr_value
from master..sysperfinfo
where counter_name = 'Connection Memory (KB)'
union
select lower('Free pages'), cntr_value
from master..sysperfinfo
where counter_name = 'Free pages' and lower(object_name) = lower(@sysperfinfoname + ':Buffer Manager')
union
select lower('Granted Workspace Memory (KB)'), cntr_value
from master..sysperfinfo
where counter_name = 'Granted Workspace Memory (KB)'
union
select lower('Lock Memory (KB)'), cntr_value
from master..sysperfinfo
where counter_name = 'Lock Memory (KB)'
union
select lower('Optimizer Memory (KB)'), cntr_value
from master..sysperfinfo
where counter_name = 'Optimizer Memory (KB)'
union
select lower('Total pages'), cntr_value
from master..sysperfinfo
where counter_name = 'Total pages' and lower(object_name) = lower(@sysperfinfoname + ':Buffer Manager')
union
select lower('Total Server Memory (KB)'), cntr_value
from master..sysperfinfo
where counter_name = 'Total Server Memory (KB)'
order by 1

