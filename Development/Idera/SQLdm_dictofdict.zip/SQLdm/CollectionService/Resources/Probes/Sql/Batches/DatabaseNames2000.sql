﻿SELECT name 'DatabaseName', dbid 'ID'
FROM master.dbo.sysdatabases