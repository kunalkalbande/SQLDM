-- SQLdm 6.2  Hashvalue: ZNR6zYSu/oGm0mahTJYwnxJBttA= 
--------------------------------------------------------------------------------
--  Batch: Table Reorganization
--  Variables: 
--		[0] - Database exclude string
--		[1] - Include system tables
--		[2] - Minimum table size in pages
--		[3] - List of databases to retry -- delete from @databases where dbid not in ()
--		[4] - List of tables to retry -- select 0, 0, 0, ''
--		[5] - Reverse order (0 or 1)
--		[6] - Timeout
--------------------------------------------------------------------------------
use master
declare 
@command nvarchar(2048), 
@dbname nvarchar(255), 
@dbid int, 
@tableid int,
@maxdb int,
@maxtable int,
@issystemtable bit,
@databasestatus int,
@proceed bit,
@reverseorder bit

declare @timeoutstart datetime
set @timeoutstart = getdate()

declare @timeout int
--set @timeout = {6}

if ({6} < 60)
	set @timeout = {6}*.9
else 
	set @timeout = {6} - 60

set @reverseorder = {5}

declare @databases table(dbid int)
declare @retrytables table(dbid int, tableid int, issystemtable int, username sysname)
 
if (select isnull(object_id('tempdb..#reorgtables'), 0)) = 0 
	create table #reorgtables(tableid int, issystemtable int, username sysname, tablename sysname) 
else
	truncate table #reorgtables

insert into @databases
select
	dbid
from 
	master..sysdatabases db
where
	lower(name) not in ('mssqlsystemresource'{0})

{3}

insert into @retrytables
	select 0, 0, 0, ''
	{4}
	

select * from @databases

if @reverseorder = 1
	update @databases set dbid = dbid * -1
		
select 
	@dbid = min(dbid),
	@maxdb = max(dbid)
from
	@databases

while @dbid <= @maxdb
begin

	if @reverseorder = 1
		set @dbid = @dbid * -1
	
	select @dbname = db_name(@dbid), @proceed = 0
	
	select @databasestatus = 
		case when isnull(mirr.mirroring_role,0) = 2 and isnull(db.state,0) = 1 then 8 else 0 end								--Restoring Mirror
		+ case when isnull(databasepropertyex(@dbname,'IsInStandby'),0) = 1 or db.is_in_standby = 1 then 16 else 0 end 			--Standby
		+ case when isnull(mirr.mirroring_role,0) <> 2 and (isnull(databaseproperty(@dbname, 'IsInLoad'),0) = 1 
			or isnull(db.state,0) = 1) then 32 else 0 end																		--Restoring (non-mirror)
		+ case when isnull(db.state,0) = 3 then 64 else 0 end																	--Pre-Recovery
		+ case when isnull(databaseproperty(@dbname, 'IsInRecovery'),0) = 1 or isnull(db.state,0) = 2 then 128 else 0 end		--Recovering
		+ case when isnull(databaseproperty(@dbname, 'IsNotRecovered'),0) = 1 or isnull(databaseproperty(@dbname, 'IsSuspect'),0) = 1 
			or isnull(databaseproperty(@dbname, 'IsShutDown'),0) = 1 or isnull(db.state,0) = 4 then 256 else 0 end				--Suspect
		+ case when isnull(databaseproperty(@dbname, 'IsOffline'),0) = 1 or isnull(db.state,0) = 6 then 512 else 0 end			--Offline
		+ case when isnull(databaseproperty(@dbname, 'IsReadOnly'),0) = 1 or isnull(db.is_read_only,0) = 1 then 1024 else 0 end --Read Only
		+ case when isnull(databaseproperty(@dbname, 'IsDboOnly'),0) = 1 then 2048 else 0 end									--DBO Use
		+ case when isnull(databaseproperty(@dbname, 'IsSingleUser'),0) = 1 or db.user_access = 1 then 4096 else 0 end			--Single User
		+ case when isnull(databaseproperty(@dbname, 'IsEmergencyMode'),0) = 1 or isnull(db.state,0) = 5 then 32768 else 0 end	--Emergency Mode	
		+ case when isnull(db.is_cleanly_shutdown,0) = 1 then 1073741824 else 0 end												--Cleanly Shutdown
	from 
		master.sys.databases db
		left outer join sys.database_mirroring mirr 
		on mirr.database_id = db.database_id
	where 
		db.database_id = @dbid

	
	-- Decide whether to collect size information
	if
		(@databasestatus & 8 <> 8 --Restoring Mirror
		and @databasestatus & 32 <> 32 --Restoring
		and @databasestatus & 64 <> 64 --Pre-Recovery
		and @databasestatus & 128 <> 128 --Recovering
		and @databasestatus & 256 <> 256 --Suspect
		and @databasestatus & 512 <> 512 --Offline
		and (@databasestatus & 4096 <> 4096
			or (@databasestatus & 4096 = 4096 
				and not exists 
				(select * from master..sysprocesses p where dbid = @dbid and p.spid <> @@spid)
				and not exists
				(select * from master.sys.dm_tran_locks l where resource_database_id = @dbid and l.request_session_id <> @@spid)
			))  --Single User
		)
			select @proceed = 1

	-- If we cannot access database, but there is no known reason, set database to Inacessible
	if	@proceed = 1 and (has_dbaccess (@dbname) <> 1)
		select @databasestatus = @databasestatus + 8192, @proceed = 0


	if @proceed = 0
	begin
		-- Try again later
		select 'Retry database', @dbname, @dbid
	end
	else
	begin
		if (select count(*) from @retrytables where dbid = @dbid) > 0
		begin
			insert into #reorgtables
				select tableid, issystemtable, username,'' from @retrytables where dbid = @dbid

			set @command = 'use [' + replace(@dbname,char(93),char(93)+char(93)) + ']' +
				N'delete from #reorgtables
				where tableid not in 
				(select 
				id
				from 
				sysobjects o
				where o.id in (select id from sysindexes where indid = 1 and rowcnt > 0 and used >= {2}) 
				and upper(o.type) in (''{1}'',''U''))
				update #reorgtables
				set tablename = object_name(tableid)'
		
			exec sp_executesql @command
		end
		else
		begin
			-- Make a list of tables
			set @command = N'use [' + replace(@dbname,char(93),char(93)+char(93)) + '] ' +
			N'select 
			id,
			issystemtable = case when category & 2 = 2 then cast(1 as bit) else cast(0 as bit) end,
			username = schema_name(o.uid),
			name
			from 
			sysobjects o
			where o.id in (select id from sysindexes where indid = 1 and rowcnt > 0 and used >= {2}) 
			and upper(o.type) in (''{1}'',''U'')'

			insert into #reorgtables
				exec sp_executesql @command
		end

		select 
			'TableList',
			@dbname, 
			@dbid,
			tableid,
			issystemtable,
			username
		from #reorgtables

		if @@rowcount = 0
			select 
				'Skip database',
				@dbname,
				@dbid

		select 
			@tableid = min(tableid),
			@maxtable = max(tableid)
		from
			#reorgtables

		if (datediff(s,@timeoutstart,getdate()) <= @timeout)
		begin
			select
				tablename,
				object_id,
				sum(avg_fragmentation_in_percent * page_count) / nullif(sum(page_count),0)
			from 
				#reorgtables r
				left join master.sys.dm_db_index_physical_stats(@dbid, null, null, null, 'limited') d
				on d.object_id = r.tableid
			where
				index_id = 1
				and alloc_unit_type_desc collate database_default = 'IN_ROW_DATA' collate database_default 
			group by
				tablename, object_id
		end

	end

	delete from #reorgtables

	if @reverseorder = 1
		delete from @databases where dbid = @dbid * -1
	else
		delete from @databases where dbid = @dbid


	if (datediff(s,@timeoutstart,getdate()) > @timeout)
	begin	
		select @dbid = @maxdb + 1
	end
	else
	begin
		select 
			@dbid = min(dbid)
		from @databases
	end
end

delete from @databases
drop table #reorgtables

